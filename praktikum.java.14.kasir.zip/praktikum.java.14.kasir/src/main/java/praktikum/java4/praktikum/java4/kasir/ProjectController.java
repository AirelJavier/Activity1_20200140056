/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.java4.praktikum.java4.kasir;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author T.U.F GAMING
 */

@Controller
public class ProjectController {
    
    
    @RequestMapping("/input")
    public String getData(HttpServletRequest data, Model Sayur){
        
        String inputnama = data.getParameter("var_nama");
        String inputHarga = data.getParameter("var_harga");
        String inputKiloan = data.getParameter("var_kiloan");
        String inputJumlah = data.getParameter("var_Jumlah");
        String inputReceived = data.getParameter("var_received");
        
        String discount = "";
        
        Double iPrice = Double.valueOf(inputHarga);
        Double iKiloan = Double.valueOf(inputKiloan);
        Double iTotal = Double.valueOf(inputJumlah);
        Double iBayar = Double.valueOf(inputReceived);
        Double PriceTotal = iPrice * iTotal;
    
        Double getTotal = null;
        
        if (PriceTotal < 16000)
        {
            getTotal = PriceTotal - (0 * PriceTotal/100);
            discount = "0%";
        }
        else if (PriceTotal >= 16000 && PriceTotal < 25000)
        {
            getTotal = PriceTotal - (10 * PriceTotal/100);
            discount = "10%";
        }
        else if (PriceTotal >= 25000)
        {
            getTotal = PriceTotal - (15 * PriceTotal/100);
            discount = "15%";
        }
        Double Kembalian = iBayar - getTotal;
        
        Sayur.addAttribute("Sayur", inputnama);
        Sayur.addAttribute("Harga", inputHarga);
        Sayur.addAttribute("HargaPerKilo", iKiloan);
        Sayur.addAttribute("Jumlah", inputJumlah);
        Sayur.addAttribute("total", getTotal);
        Sayur.addAttribute("discount", discount);
        Sayur.addAttribute("Bayar", inputReceived);
        Sayur.addAttribute("Kembalian", Kembalian);
        
        return "ViewController";
    }
}
