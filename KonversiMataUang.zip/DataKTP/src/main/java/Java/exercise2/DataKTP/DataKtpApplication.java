package Java.exercise2.DataKTP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataKtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataKtpApplication.class, args);
	}

}
