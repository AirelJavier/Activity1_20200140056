/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java.exercise2.DataKTP;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author T.U.F GAMING
 */
@Controller
public class ProjectController {
    
    @RequestMapping("/input")
    public String getData(HttpServletRequest data, Model Convertprocess){
           
        String inputUSD = data.getParameter("var_USD");
        String inputJPY = data.getParameter("var_JPY");
        
        Double iUSD = Double.valueOf(inputUSD);
        Double iJPY = Double.valueOf(inputJPY);
        Double iTotalJPY = 115.78;
        Double iTotalUSD = 0.0086;
        Double USDtoJPY = iUSD * iTotalJPY;
        Double JPYtoUSD = iJPY * iTotalUSD;
        Double getTotalUSD = USDtoJPY;
        Double getTotalJPY = JPYtoUSD;
        
        
        Convertprocess.addAttribute("USD", inputUSD);
        Convertprocess.addAttribute("JPY", inputJPY);
        Convertprocess.addAttribute("totalConvertUSD", getTotalUSD);
        Convertprocess.addAttribute("totalConvertJPY", getTotalJPY);
        
        return "ProjectView";
    }
}
